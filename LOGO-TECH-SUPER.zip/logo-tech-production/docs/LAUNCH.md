# Launch playbook

1. Supabase schema + auth (SQL files)  
2. Env keys on Vercel  
3. Sign up admin email  
4. Upload first knowledge pack (brand, products, proposal templates)  
5. Set system prompt for LOGO-TECH voice  
6. Invite team via Supabase Auth  
7. Optional: custom domain + analytics  

Phase 2: fine-tune on farm/climate data; automation workers; mobile app on same API.
