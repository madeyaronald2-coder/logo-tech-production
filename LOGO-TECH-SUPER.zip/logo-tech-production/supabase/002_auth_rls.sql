create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    case when lower(new.email) = 'logotech1982@gmail.com' then 'admin' else 'user' end
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users for each row execute procedure public.handle_new_user();

alter table profiles enable row level security;
alter table chats enable row level security;
alter table messages enable row level security;
alter table documents enable row level security;
alter table system_config enable row level security;
alter table projects enable row level security;

create policy profiles_select on profiles for select using (
  auth.uid() = id or exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin')
);
create policy profiles_update on profiles for update using (auth.uid() = id);
create policy chats_own on chats for all using (auth.uid() = user_id);
create policy messages_own on messages for all using (
  exists (select 1 from chats c where c.id = chat_id and c.user_id = auth.uid())
);
create policy documents_read on documents for select using (auth.uid() is not null);
create policy documents_admin on documents for insert with check (
  exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin')
);
create policy documents_admin_del on documents for delete using (
  exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin')
);
create policy config_read on system_config for select using (true);
create policy config_admin on system_config for all using (
  exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin')
);
create policy projects_own on projects for all using (auth.uid() = user_id);
