create or replace function match_document_chunks(
  query_embedding vector(1536),
  match_count int default 5
)
returns table (id uuid, content text, similarity float)
language sql stable as $$
  select dc.id, dc.content,
    1 - (dc.embedding <=> query_embedding) as similarity
  from document_chunks dc
  where dc.embedding is not null
  order by dc.embedding <=> query_embedding
  limit match_count;
$$;
