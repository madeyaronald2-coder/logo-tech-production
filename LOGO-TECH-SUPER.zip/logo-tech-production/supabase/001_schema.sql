create extension if not exists vector;

create table if not exists organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'LOGO-TECH',
  plan text default 'pro',
  created_at timestamptz default now()
);

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null,
  full_name text,
  role text not null default 'user' check (role in ('user', 'admin')),
  org_id uuid references organizations(id),
  created_at timestamptz default now()
);

create table if not exists system_config (
  key text primary key,
  value text not null,
  updated_at timestamptz default now(),
  updated_by uuid references profiles(id)
);

insert into system_config (key, value) values
  ('system_prompt', 'You are LOGO-TECH AI, the Champion of Solutions. You help with agriculture, climate, technology, business, and practical problem-solving. Be direct, clear, and useful. Answer in the conversation itself — do not tell users to download code unless they ask for files.')
on conflict (key) do nothing;

create table if not exists chats (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  title text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references chats(id) on delete cascade,
  role text not null check (role in ('user', 'assistant', 'system')),
  content text not null,
  media_urls jsonb default '[]',
  created_at timestamptz default now()
);

create table if not exists documents (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references organizations(id),
  uploaded_by uuid references profiles(id),
  name text not null,
  storage_path text,
  status text default 'pending',
  created_at timestamptz default now()
);

create table if not exists document_chunks (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references documents(id) on delete cascade,
  content text not null,
  embedding vector(1536),
  chunk_index int default 0
);

create index if not exists document_chunks_embedding_idx
  on document_chunks using ivfflat (embedding vector_cosine_ops) with (lists = 100);

create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id),
  name text not null,
  metadata jsonb default '{}',
  created_at timestamptz default now()
);
