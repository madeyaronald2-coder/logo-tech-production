create table if not exists agent_memory (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  summary text not null,
  created_at timestamptz default now()
);

create index if not exists agent_memory_user_idx on agent_memory (user_id, created_at desc);

alter table agent_memory enable row level security;
create policy memory_own on agent_memory for all using (auth.uid() = user_id);
