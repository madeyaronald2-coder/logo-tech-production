# LOGO-TECH AI — Production Platform

**Champion of Solutions**

Serious full-stack AI product: multi-user auth, live chat, admin-controlled brain, knowledge RAG, server-side images.

## One command after setup

```bash
npm install
cp .env.example .env.local   # fill keys
npm run dev
```

## Setup checklist

### A. Supabase (15 minutes)
1. Create project → https://supabase.com  
2. SQL Editor run **in order**:
   - `supabase/001_schema.sql`
   - `supabase/002_auth_rls.sql`
   - `supabase/003_rag.sql`
3. Authentication → Providers → Email + Google  
4. Copy URL, anon key, service_role key into `.env.local`

### B. AI keys (server only)
- `GROQ_API_KEY` — live chat (required)
- `OPENAI_API_KEY` — embeddings for RAG (recommended)
- `REPLICATE_API_TOKEN` — real images (optional)

### C. Admin
Sign up with **logotech1982@gmail.com** → automatic `admin` role.  
Open **/admin** → system prompt + knowledge documents.

### D. Deploy worldwide
Push to GitHub → Vercel Import → same env vars → custom domain.

## Product map

| Route | Purpose |
|-------|---------|
| `/login` | Email + Google auth |
| `/chat` | Live Grok-style AI (answers in chat) |
| `/imagine` | Real image generation |
| `/admin` | Upgrade system prompt + RAG docs |
| `/api/chat` | Authenticated LLM + knowledge |
| `/api/documents` | Admin document ingest |
| `/api/image` | Server Replicate |

## Why this can scale

- Keys never ship to the browser  
- Every user gets the same upgraded brain when admin saves  
- Documents teach the AI your proposals and policies  
- Path to fine-tuning: train offline → set model id in config  

## Security
Use Supabase Auth only. Do not hardcode production passwords in source.

Built for LOGO-TECH — Champion of Solutions.

## Super Agent (v1 power core)

Integrated in `/api/chat` via `app/lib/super-agent.ts`:

- **Multi-step tool use** — knowledge_search, generate_image, analyze_data, draft_document, farm_advisor
- **RAG fusion** — knowledge docs injected every turn
- **Session memory** — summaries stored in `agent_memory` (run `004_memory.sql`)
- **Admin-controlled personality** — system_prompt from database
- **Image tools** — agent can call image generation mid-conversation

This is advanced product AI engineering (orchestration + tools + memory + RAG), not a claim of AGI.
