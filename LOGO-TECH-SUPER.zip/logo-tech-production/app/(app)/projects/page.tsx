'use client';
export default function Page() {
  return (
    <div style={{ padding: 32, maxWidth: 640, margin: '0 auto' }}>
      <a href="/chat" style={{ color: '#1e3a8a' }}>← Chat</a>
      <h1 style={{ color: '#1e3a8a', textTransform: 'capitalize' }}>projects</h1>
      <p style={{ color: '#64748b' }}>Connected to LOGO-TECH backend. Extend this view with your product data.</p>
    </div>
  );
}
