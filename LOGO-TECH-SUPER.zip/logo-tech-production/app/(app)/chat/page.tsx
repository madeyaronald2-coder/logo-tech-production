'use client';
import { useEffect, useState, useRef } from 'react';
import { createBrowserClient } from '@/app/lib/supabase';
import { useRouter } from 'next/navigation';

type Msg = { role: 'user' | 'assistant'; content: string; imageUrl?: string };

export default function ChatPage() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [chatId, setChatId] = useState<string>();
  const [token, setToken] = useState<string | null>(null);
  const [email, setEmail] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const bottom = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const supabase = createBrowserClient();

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => {
      const t = data.session?.access_token ?? null;
      setToken(t);
      setEmail(data.session?.user?.email || '');
      if (!t) router.replace('/login');
      else {
        const { data: p } = await supabase.from('profiles').select('role').eq('id', data.session!.user.id).single();
        setIsAdmin(p?.role === 'admin');
      }
    });
  }, []);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  async function send(text?: string) {
    const msg = (text ?? input).trim();
    if (!msg || !token) return;
    setInput('');
    setMessages((m) => [...m, { role: 'user', content: msg }]);
    setLoading(true);
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ message: msg, chatId }),
      });
      const data = await res.json();
      if (data.chatId) setChatId(data.chatId);
      setMessages((m) => [...m, {
        role: 'assistant',
        content: data.reply || data.error || 'No response',
        imageUrl: data.imageUrl,
      }]);
    } catch (e: unknown) {
      setMessages((m) => [...m, { role: 'assistant', content: 'Error: ' + (e instanceof Error ? e.message : String(e)) }]);
    } finally {
      setLoading(false);
    }
  }

  async function newChat() {
    setChatId(undefined);
    setMessages([]);
  }

  async function signOut() {
    await supabase.auth.signOut();
    router.replace('/login');
  }

  if (!token) {
    return <div style={{ padding: 40, textAlign: 'center' }}>Loading…</div>;
  }

  const nav = [
    { href: '/chat', label: '💬 Chat' },
    { href: '/imagine', label: '🖼️ Imagine' },
    { href: '/library', label: '📚 Library' },
    { href: '/projects', label: '📁 Projects' },
    { href: '/settings', label: '⚙️ Settings' },
  ];
  if (isAdmin) nav.push({ href: '/admin', label: '🛠️ Admin' });

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <aside style={{ width: 240, background: '#fff', borderRight: '1px solid #e2e8f0', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: 16, borderBottom: '1px solid #e2e8f0', display: 'flex', gap: 10, alignItems: 'center' }}>
          <img src="/logo.jpg" width={40} height={40} alt="" style={{ borderRadius: '50%', border: '2px solid #1e3a8a' }} />
          <div>
            <div style={{ fontWeight: 700, color: '#1e3a8a', fontSize: 13 }}>LOGO-TECH AI</div>
            <div style={{ fontSize: 11, color: '#64748b' }}>Champion of Solutions</div>
          </div>
        </div>
        <button onClick={newChat} style={{ margin: 12, padding: 10, borderRadius: 10, border: 0, background: '#1e3a8a', color: '#fff', fontWeight: 600, cursor: 'pointer' }}>
          + New chat
        </button>
        <nav style={{ flex: 1, padding: '0 8px' }}>
          {nav.map((n) => (
            <a key={n.href} href={n.href} style={{ display: 'block', padding: '10px 12px', borderRadius: 10, textDecoration: 'none', color: '#334155', fontSize: 14, marginBottom: 2 }}>
              {n.label}
            </a>
          ))}
        </nav>
        <div style={{ padding: 12, borderTop: '1px solid #e2e8f0', fontSize: 12 }}>
          <div style={{ fontWeight: 600 }}>{email || 'User'}</div>
          <button onClick={signOut} style={{ marginTop: 6, border: 0, background: 'none', color: '#64748b', cursor: 'pointer', fontSize: 12 }}>Sign out</button>
        </div>
      </aside>

      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <header style={{ height: 52, borderBottom: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', padding: '0 20px', background: '#fff' }}>
          <strong style={{ fontSize: 14 }}>Chat</strong>
        </header>
        <div style={{ flex: 1, overflow: 'auto', padding: 20 }}>
          {messages.length === 0 && (
            <div style={{ maxWidth: 560, margin: '40px auto', textAlign: 'center', color: '#64748b' }}>
              <h2 style={{ color: '#1e3a8a' }}>How can LOGO-TECH help?</h2>
              <p style={{ fontSize: 14 }}>Ask about farms, climate, technology, proposals — answers appear here live.</p>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start', marginBottom: 14 }}>
              <div style={{
                maxWidth: '75%',
                padding: '12px 16px',
                borderRadius: 14,
                background: m.role === 'user' ? '#1e3a8a' : '#fff',
                color: m.role === 'user' ? '#fff' : '#0f172a',
                border: m.role === 'assistant' ? '1px solid #e2e8f0' : 'none',
                fontSize: 14,
                whiteSpace: 'pre-wrap',
                lineHeight: 1.5,
              }}>
                {m.imageUrl && <img src={m.imageUrl} alt="" style={{ maxWidth: '100%', borderRadius: 8, marginBottom: 8 }} />}
                {m.content}
              </div>
            </div>
          ))}
          {loading && <p style={{ color: '#94a3b8', fontSize: 13 }}>Thinking…</p>}
          <div ref={bottom} />
        </div>
        <div style={{ padding: 16, borderTop: '1px solid #e2e8f0', background: '#fff' }}>
          <div style={{ maxWidth: 720, margin: '0 auto', display: 'flex', gap: 8 }}>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
              rows={2}
              placeholder="Message LOGO-TECH AI…"
              style={{ flex: 1, padding: 12, borderRadius: 12, border: '1px solid #cbd5e1', resize: 'none', fontSize: 14 }}
            />
            <button onClick={() => send()} disabled={loading}
              style={{ padding: '0 20px', borderRadius: 12, border: 0, background: '#1e3a8a', color: '#fff', fontWeight: 600, cursor: 'pointer' }}>
              Send
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
