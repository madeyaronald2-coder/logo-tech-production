'use client';
import { useEffect, useState } from 'react';
import { createBrowserClient } from '@/app/lib/supabase';
import { useRouter } from 'next/navigation';

export default function ImaginePage() {
  const [token, setToken] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [status, setStatus] = useState('');
  const router = useRouter();

  useEffect(() => {
    createBrowserClient().auth.getSession().then(({ data }) => {
      const t = data.session?.access_token ?? null;
      setToken(t);
      if (!t) router.replace('/login');
    });
  }, []);

  async function generate() {
    if (!token || !prompt.trim()) return;
    setStatus('Generating…');
    setImageUrl('');
    const res = await fetch('/api/image', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: prompt.trim() }),
    });
    const data = await res.json();
    if (data.imageUrl) {
      setImageUrl(data.imageUrl);
      setStatus('Done');
    } else {
      setStatus(data.error || 'Failed');
    }
  }

  return (
    <div style={{ maxWidth: 640, margin: '0 auto', padding: 32 }}>
      <a href="/chat" style={{ color: '#1e3a8a', fontSize: 14 }}>← Chat</a>
      <h1 style={{ color: '#1e3a8a' }}>Imagine</h1>
      <p style={{ color: '#64748b', fontSize: 14 }}>Real images via server-side generation (Replicate).</p>
      <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={4} placeholder="Describe the image…"
        style={{ width: '100%', padding: 12, borderRadius: 10, border: '1px solid #cbd5e1' }} />
      <button onClick={generate} style={{ marginTop: 10, padding: '10px 18px', background: '#1e3a8a', color: '#fff', border: 0, borderRadius: 8, cursor: 'pointer' }}>
        Generate
      </button>
      {status && <p style={{ marginTop: 12, fontSize: 14 }}>{status}</p>}
      {imageUrl && <img src={imageUrl} alt="Generated" style={{ marginTop: 16, maxWidth: '100%', borderRadius: 12 }} />}
    </div>
  );
}
