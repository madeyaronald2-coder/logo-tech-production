'use client';
import { useEffect, useState } from 'react';
import { createBrowserClient } from '@/app/lib/supabase';
import { useRouter } from 'next/navigation';

export default function AdminPage() {
  const [token, setToken] = useState<string | null>(null);
  const [systemPrompt, setSystemPrompt] = useState('');
  const [docName, setDocName] = useState('knowledge.txt');
  const [docContent, setDocContent] = useState('');
  const [docs, setDocs] = useState<{ id: string; name: string; status: string }[]>([]);
  const [status, setStatus] = useState('');
  const router = useRouter();

  useEffect(() => {
    const supabase = createBrowserClient();
    supabase.auth.getSession().then(async ({ data }) => {
      const t = data.session?.access_token ?? null;
      if (!t) { router.replace('/login'); return; }
      setToken(t);
      const { data: p } = await supabase.from('profiles').select('role').eq('id', data.session!.user.id).single();
      if (p?.role !== 'admin') { setStatus('Admin access required'); return; }
      load(t);
    });
  }, []);

  async function load(t: string) {
    const c = await fetch('/api/admin/config', { headers: { Authorization: `Bearer ${t}` } });
    const cj = await c.json();
    if (cj.system_prompt) setSystemPrompt(cj.system_prompt);
    const d = await fetch('/api/documents', { headers: { Authorization: `Bearer ${t}` } });
    const dj = await d.json();
    setDocs(dj.documents || []);
  }

  async function savePrompt() {
    if (!token) return;
    const res = await fetch('/api/admin/config', {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ system_prompt: systemPrompt }),
    });
    setStatus(res.ok ? 'System prompt saved — applies to all users.' : 'Save failed');
  }

  async function upload() {
    if (!token || !docContent.trim()) return;
    setStatus('Embedding document…');
    const res = await fetch('/api/documents', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: docName, content: docContent }),
    });
    const data = await res.json();
    setStatus(res.ok ? `Ready: ${data.chunks} chunks indexed.` : data.error || 'Failed');
    if (token) load(token);
  }

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: 32 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ color: '#1e3a8a' }}>Admin / Developer</h1>
        <a href="/chat" style={{ color: '#1e3a8a' }}>← Chat</a>
      </div>
      <p style={{ color: '#64748b', fontSize: 14 }}>
        Changes here upgrade LOGO-TECH for every signed-in user.
      </p>

      <section style={{ marginTop: 28, background: '#fff', padding: 20, borderRadius: 12, border: '1px solid #e2e8f0' }}>
        <h3 style={{ marginTop: 0 }}>System instructions</h3>
        <textarea value={systemPrompt} onChange={(e) => setSystemPrompt(e.target.value)} rows={8}
          style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid #cbd5e1', fontFamily: 'inherit', fontSize: 14 }} />
        <button onClick={savePrompt} style={{ marginTop: 10, padding: '10px 18px', background: '#1e3a8a', color: '#fff', border: 0, borderRadius: 8, cursor: 'pointer' }}>
          Save system prompt
        </button>
      </section>

      <section style={{ marginTop: 24, background: '#fff', padding: 20, borderRadius: 12, border: '1px solid #e2e8f0' }}>
        <h3 style={{ marginTop: 0 }}>Knowledge base (RAG)</h3>
        <p style={{ fontSize: 13, color: '#64748b' }}>Upload proposal templates, farm notes, policies. The AI uses them when answering.</p>
        <input value={docName} onChange={(e) => setDocName(e.target.value)} style={{ width: '100%', padding: 10, marginBottom: 8, borderRadius: 8, border: '1px solid #cbd5e1' }} />
        <textarea value={docContent} onChange={(e) => setDocContent(e.target.value)} rows={10} placeholder="Paste document text…"
          style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid #cbd5e1', fontSize: 14 }} />
        <button onClick={upload} style={{ marginTop: 10, padding: '10px 18px', background: '#1e3a8a', color: '#fff', border: 0, borderRadius: 8, cursor: 'pointer' }}>
          Upload & embed
        </button>
        <ul style={{ marginTop: 16, fontSize: 13 }}>
          {docs.map((d) => (
            <li key={d.id}>{d.name} — <strong>{d.status}</strong></li>
          ))}
        </ul>
      </section>

      {status && <p style={{ marginTop: 16, color: '#1e3a8a', fontWeight: 500 }}>{status}</p>}
    </div>
  );
}
