'use client';
import { useState } from 'react';
import { createBrowserClient } from '@/app/lib/supabase';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState<'in' | 'up'>('in');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const supabase = createBrowserClient();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      if (mode === 'in') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        router.push('/chat');
      } else {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        setError('Account created. Sign in (confirm email if required).');
        setMode('in');
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function google() {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: window.location.origin + '/chat' },
    });
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ width: '100%', maxWidth: 400, background: '#fff', borderRadius: 16, padding: 32, boxShadow: '0 4px 24px rgba(0,0,0,.08)' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <img src="/logo.jpg" alt="LOGO-TECH" width={64} height={64} style={{ borderRadius: '50%', border: '2px solid #1e3a8a' }} />
          <h1 style={{ margin: '12px 0 4px', color: '#1e3a8a', fontSize: 22 }}>LOGO-TECH AI</h1>
          <p style={{ margin: 0, color: '#64748b', fontSize: 13 }}>Champion of Solutions</p>
        </div>
        <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <input type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)}
            style={{ padding: 12, borderRadius: 10, border: '1px solid #cbd5e1', fontSize: 14 }} />
          <input type="password" required placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}
            style={{ padding: 12, borderRadius: 10, border: '1px solid #cbd5e1', fontSize: 14 }} />
          {error && <p style={{ color: '#dc2626', fontSize: 13, margin: 0 }}>{error}</p>}
          <button type="submit" disabled={busy}
            style={{ padding: 12, borderRadius: 10, border: 0, background: '#1e3a8a', color: '#fff', fontWeight: 600, cursor: 'pointer' }}>
            {busy ? '…' : mode === 'in' ? 'Sign in' : 'Create account'}
          </button>
        </form>
        <button type="button" onClick={google}
          style={{ width: '100%', marginTop: 12, padding: 11, borderRadius: 10, border: '1px solid #cbd5e1', background: '#fff', cursor: 'pointer' }}>
          Continue with Google
        </button>
        <p style={{ textAlign: 'center', marginTop: 16, fontSize: 13, color: '#64748b' }}>
          {mode === 'in' ? (
            <>No account? <button type="button" onClick={() => setMode('up')} style={{ border: 0, background: 'none', color: '#1e3a8a', cursor: 'pointer' }}>Sign up</button></>
          ) : (
            <>Have an account? <button type="button" onClick={() => setMode('in')} style={{ border: 0, background: 'none', color: '#1e3a8a', cursor: 'pointer' }}>Sign in</button></>
          )}
        </p>
      </div>
    </div>
  );
}
