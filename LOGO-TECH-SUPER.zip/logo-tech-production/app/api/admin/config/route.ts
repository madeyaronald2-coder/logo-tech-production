import { requireAdmin } from '@/app/lib/supabase';

export async function GET(req: Request) {
  const admin = await requireAdmin(req);
  if (!admin) return Response.json({ error: 'Admin only' }, { status: 403 });
  const { data } = await admin.supabase.from('system_config').select('key, value');
  const map: Record<string, string> = {};
  (data || []).forEach((r: { key: string; value: string }) => {
    map[r.key] = r.value;
  });
  return Response.json(map);
}

export async function PUT(req: Request) {
  const admin = await requireAdmin(req);
  if (!admin) return Response.json({ error: 'Admin only' }, { status: 403 });
  const body = await req.json();
  if (body.system_prompt != null) {
    await admin.supabase.from('system_config').upsert({
      key: 'system_prompt',
      value: String(body.system_prompt),
      updated_at: new Date().toISOString(),
      updated_by: admin.user.id,
    });
  }
  return Response.json({ ok: true });
}
