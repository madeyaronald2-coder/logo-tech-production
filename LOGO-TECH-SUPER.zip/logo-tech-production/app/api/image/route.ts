import { generateImage } from '@/app/lib/ai';
import { requireUser } from '@/app/lib/supabase';

export async function POST(req: Request) {
  const ctx = await requireUser(req);
  if (!ctx) return Response.json({ error: 'Unauthorized' }, { status: 401 });
  const { prompt } = await req.json();
  if (!prompt?.trim()) return Response.json({ error: 'prompt required' }, { status: 400 });
  try {
    const imageUrl = await generateImage(prompt.trim());
    if (!imageUrl)
      return Response.json(
        { error: 'Set REPLICATE_API_TOKEN on the server for real images' },
        { status: 503 }
      );
    return Response.json({ imageUrl });
  } catch (e: unknown) {
    return Response.json(
      { error: e instanceof Error ? e.message : String(e) },
      { status: 500 }
    );
  }
}
