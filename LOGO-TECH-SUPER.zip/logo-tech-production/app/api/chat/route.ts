import { requireUser } from '@/app/lib/supabase';
import { runSuperAgent } from '@/app/lib/super-agent';

export async function POST(req: Request) {
  try {
    const ctx = await requireUser(req);
    if (!ctx) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const message = (body.message || '').trim();
    if (!message) return Response.json({ error: 'message required' }, { status: 400 });
    let chatId = body.chatId as string | undefined;

    const { data: cfg } = await ctx.supabase
      .from('system_config')
      .select('value')
      .eq('key', 'system_prompt')
      .maybeSingle();

    const systemPrompt =
      cfg?.value ||
      `You are LOGO-TECH AI — Champion of Solutions.
You are a highly capable assistant for agriculture, climate risk, water systems, livestock, technology, and business strategy.
You reason carefully, use tools when needed, and deliver complete answers in the conversation.
You are practical, precise, and solution-oriented.`;

    if (!chatId) {
      const { data: chat, error } = await ctx.supabase
        .from('chats')
        .insert({ user_id: ctx.user.id, title: message.slice(0, 80) })
        .select('id')
        .single();
      if (error) throw error;
      chatId = chat.id;
    }

    await ctx.supabase.from('messages').insert({
      chat_id: chatId,
      role: 'user',
      content: message,
    });

    const { data: history } = await ctx.supabase
      .from('messages')
      .select('role, content')
      .eq('chat_id', chatId)
      .order('created_at', { ascending: true })
      .limit(20);

    const result = await runSuperAgent({
      userMessage: message,
      systemPrompt,
      history: (history || []).map((m: { role: string; content: string }) => ({
        role: m.role,
        content: m.content,
      })),
      userId: ctx.user.id,
    });

    const media = result.imageUrl ? [result.imageUrl] : [];
    await ctx.supabase.from('messages').insert({
      chat_id: chatId,
      role: 'assistant',
      content: result.reply,
      media_urls: media,
    });

    await ctx.supabase
      .from('chats')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', chatId);

    return Response.json({
      reply: result.reply,
      chatId,
      imageUrl: result.imageUrl,
      toolsUsed: result.toolsUsed,
      plan: result.plan,
      confidence: result.confidence,
    });
  } catch (e: unknown) {
    console.error(e);
    return Response.json(
      { error: e instanceof Error ? e.message : String(e) },
      { status: 500 }
    );
  }
}
