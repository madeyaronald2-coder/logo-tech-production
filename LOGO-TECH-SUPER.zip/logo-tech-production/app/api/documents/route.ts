import { requireUser, requireAdmin, createServiceClient } from '@/app/lib/supabase';
import { ingestDocument } from '@/app/lib/rag';

export async function GET(req: Request) {
  const ctx = await requireUser(req);
  if (!ctx) return Response.json({ error: 'Unauthorized' }, { status: 401 });
  const { data, error } = await ctx.supabase
    .from('documents')
    .select('id, name, status, created_at')
    .order('created_at', { ascending: false });
  if (error) return Response.json({ error: error.message }, { status: 500 });
  return Response.json({ documents: data });
}

export async function POST(req: Request) {
  const admin = await requireAdmin(req);
  if (!admin) return Response.json({ error: 'Admin only' }, { status: 403 });

  const body = await req.json();
  const name = (body.name || 'document.txt').trim();
  const content = (body.content || '').trim();
  if (!content) return Response.json({ error: 'content required' }, { status: 400 });

  const service = createServiceClient();
  const { data: doc, error } = await service
    .from('documents')
    .insert({ name, uploaded_by: admin.user.id, status: 'pending' })
    .select('id')
    .single();
  if (error) return Response.json({ error: error.message }, { status: 500 });

  try {
    const result = await ingestDocument(doc.id, content);
    return Response.json({ id: doc.id, ...result });
  } catch (e: unknown) {
    await service.from('documents').update({ status: 'error' }).eq('id', doc.id);
    return Response.json(
      { error: e instanceof Error ? e.message : String(e), id: doc.id },
      { status: 500 }
    );
  }
}
