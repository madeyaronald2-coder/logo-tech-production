/**
 * LOGO-TECH Super Agent
 * Multi-step reasoning · tools · memory · model routing · RAG fusion
 */

import { chatCompletion, generateImage, embedText } from './ai';
import { retrieveContext } from './rag';
import { createServiceClient } from './supabase';

export type AgentMessage = { role: 'system' | 'user' | 'assistant' | 'tool'; content: string; name?: string };

export type AgentResult = {
  reply: string;
  imageUrl?: string;
  toolsUsed: string[];
  plan?: string[];
  confidence?: number;
};

const TOOL_SPECS = `
You have tools. When you need one, output ONLY a JSON block:
{"tool":"TOOL_NAME","input":{...}}

Tools:
1. knowledge_search — search company/knowledge documents. input: {"query":"..."}
2. generate_image — create an image. input: {"prompt":"..."}
3. analyze_data — reason over numbers/tables. input: {"description":"...","data":"..."}
4. draft_document — structured long-form (proposal, report). input: {"type":"proposal|report|plan","topic":"...","constraints":"..."}
5. farm_advisor — agriculture/climate specialist reasoning. input: {"question":"...","context":"..."}

If no tool is needed, answer the user directly in clear prose.
After tool results are provided, synthesize a final answer for the user.
`;

async function runTool(
  name: string,
  input: Record<string, unknown>,
  userId?: string
): Promise<string> {
  switch (name) {
    case 'knowledge_search': {
      const q = String(input.query || '');
      const ctx = await retrieveContext(q, 8);
      return ctx || 'No matching knowledge found.';
    }
    case 'generate_image': {
      const prompt = String(input.prompt || '');
      const url = await generateImage(prompt);
      if (url) return JSON.stringify({ imageUrl: url, status: 'ok' });
      return JSON.stringify({ status: 'unavailable', message: 'Image provider not configured' });
    }
    case 'analyze_data': {
      return `Analysis request received.\nDescription: ${input.description}\nData:\n${input.data}\nProvide quantitative reasoning in the final answer.`;
    }
    case 'draft_document': {
      return `Draft request: type=${input.type}, topic=${input.topic}, constraints=${input.constraints}. Produce a complete professional document in the final answer.`;
    }
    case 'farm_advisor': {
      const q = String(input.question || '');
      const extra = await retrieveContext(q + ' ' + String(input.context || ''), 5);
      return `Farm/climate specialist context:\n${extra || 'Use general best practices.'}\nQuestion: ${q}`;
    }
    default:
      return `Unknown tool: ${name}`;
  }
}

function extractToolCall(text: string): { tool: string; input: Record<string, unknown> } | null {
  const match = text.match(/\{[\s\S]*"tool"[\s\S]*\}/);
  if (!match) return null;
  try {
    const obj = JSON.parse(match[0]);
    if (obj.tool && typeof obj.tool === 'string') return obj;
  } catch {
    /* ignore */
  }
  return null;
}

/** Persist a short memory summary for the user (optional table agent_memory) */
export async function saveMemory(userId: string, summary: string) {
  try {
    const sb = createServiceClient();
    await sb.from('agent_memory').insert({
      user_id: userId,
      summary: summary.slice(0, 2000),
    });
  } catch {
    /* table may not exist yet */
  }
}

export async function loadMemory(userId: string): Promise<string> {
  try {
    const sb = createServiceClient();
    const { data } = await sb
      .from('agent_memory')
      .select('summary')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(5);
    if (!data?.length) return '';
    return data.map((r: { summary: string }) => r.summary).join('\n');
  } catch {
    return '';
  }
}

/**
 * Main super-agent loop: plan → tools (up to 3) → final answer
 */
export async function runSuperAgent(opts: {
  userMessage: string;
  systemPrompt: string;
  history: { role: string; content: string }[];
  userId?: string;
}): Promise<AgentResult> {
  const toolsUsed: string[] = [];
  let imageUrl: string | undefined;
  const plan: string[] = [];

  const memory = opts.userId ? await loadMemory(opts.userId) : '';
  const rag = await retrieveContext(opts.userMessage, 6).catch(() => '');

  const system = `${opts.systemPrompt}

${TOOL_SPECS}

${memory ? `User memory (past sessions):\n${memory}\n` : ''}
${rag ? `Knowledge base excerpts:\n${rag}\n` : ''}

Operating rules:
- Think step by step when the task is complex.
- Prefer accurate, structured, actionable answers.
- For agriculture, climate, water, livestock: be practical and region-aware when possible.
- Never claim you cannot help with images if the generate_image tool exists — use it.
- Final answers must be complete and ready for the user (not code dumps unless asked).
`;

  const messages: AgentMessage[] = [
    { role: 'system', content: system },
    ...opts.history.map((h) => ({
      role: h.role as AgentMessage['role'],
      content: h.content,
    })),
    { role: 'user', content: opts.userMessage },
  ];

  // Up to 3 tool rounds
  for (let round = 0; round < 3; round++) {
    const raw = await chatCompletion(
      messages.map((m) => ({ role: m.role === 'tool' ? 'user' : m.role, content: m.content }))
    );

    const call = extractToolCall(raw);
    if (!call) {
      // Final natural language answer
      if (opts.userId && opts.userMessage.length > 20) {
        saveMemory(
          opts.userId,
          `User asked about: ${opts.userMessage.slice(0, 120)}. Assistant focused on solution.`
        ).catch(() => {});
      }
      return {
        reply: raw,
        imageUrl,
        toolsUsed,
        plan: plan.length ? plan : undefined,
        confidence: toolsUsed.length ? 0.9 : 0.85,
      };
    }

    plan.push(`Use ${call.tool}`);
    toolsUsed.push(call.tool);
    messages.push({ role: 'assistant', content: raw });

    const toolResult = await runTool(call.tool, call.input || {}, opts.userId);
    if (call.tool === 'generate_image') {
      try {
        const parsed = JSON.parse(toolResult);
        if (parsed.imageUrl) imageUrl = parsed.imageUrl;
      } catch {
        /* ignore */
      }
    }

    messages.push({
      role: 'tool',
      name: call.tool,
      content: `Tool ${call.tool} result:\n${toolResult}`,
    });
    messages.push({
      role: 'user',
      content:
        'Using the tool result above, continue. If you need another tool, emit JSON again. Otherwise give the final answer to the user in clear prose.',
    });
  }

  // Force final synthesis
  const final = await chatCompletion(
    messages
      .map((m) => ({ role: m.role === 'tool' ? 'user' : m.role, content: m.content }))
      .concat([
        {
          role: 'user',
          content: 'Give the final complete answer now. No more tools.',
        },
      ])
  );

  return { reply: final, imageUrl, toolsUsed, plan, confidence: 0.88 };
}
