import { embedText } from './ai';
import { createServiceClient } from './supabase';

const CHUNK_SIZE = 900;
const OVERLAP = 120;

export function chunkText(text: string): string[] {
  const clean = text.replace(/\r/g, '').trim();
  if (!clean) return [];
  const chunks: string[] = [];
  let i = 0;
  while (i < clean.length) {
    chunks.push(clean.slice(i, i + CHUNK_SIZE));
    i += CHUNK_SIZE - OVERLAP;
  }
  return chunks;
}

export async function ingestDocument(documentId: string, content: string) {
  const supabase = createServiceClient();
  const chunks = chunkText(content);
  await supabase.from('documents').update({ status: 'processing' }).eq('id', documentId);

  for (let idx = 0; idx < chunks.length; idx++) {
    const embedding = await embedText(chunks[idx]);
    await supabase.from('document_chunks').insert({
      document_id: documentId,
      content: chunks[idx],
      chunk_index: idx,
      embedding,
    });
  }
  await supabase.from('documents').update({ status: 'ready' }).eq('id', documentId);
  return { chunks: chunks.length };
}

export async function retrieveContext(query: string, limit = 5): Promise<string> {
  const embedding = await embedText(query);
  const supabase = createServiceClient();

  if (embedding) {
    const { data, error } = await supabase.rpc('match_document_chunks', {
      query_embedding: embedding,
      match_count: limit,
    });
    if (!error && data?.length) {
      return data.map((r: { content: string }) => r.content).join('\n\n---\n\n');
    }
  }

  const { data: fallback } = await supabase
    .from('document_chunks')
    .select('content')
    .limit(limit);
  return (fallback || []).map((r: { content: string }) => r.content).join('\n\n');
}
