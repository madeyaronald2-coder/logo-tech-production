import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'LOGO-TECH AI — Champion of Solutions',
  description: 'Global AI platform for agriculture, climate, and technology',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/logo.jpg" />
      </head>
      <body
        style={{
          margin: 0,
          fontFamily: 'Inter, system-ui, -apple-system, sans-serif',
          background: '#f8fafc',
          color: '#0f172a',
          minHeight: '100vh',
        }}
      >
        {children}
      </body>
    </html>
  );
}
